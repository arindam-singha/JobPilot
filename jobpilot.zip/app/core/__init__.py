"""Core application components."""
