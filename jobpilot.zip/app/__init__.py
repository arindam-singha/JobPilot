"""JobPilot application package."""
