from __future__ import annotations

import json

import httpx
from pydantic import ValidationError

from app.llm.job_requirements_provider import (
    JobRequirementsProviderError,
)
from app.schemas.job_requirements import JobRequirementsData


SYSTEM_PROMPT = """
You extract structured hiring requirements from job descriptions.

Return only information explicitly supported by the supplied job title,
company, location, and description.

Rules:
- Do not invent skills, responsibilities, education, certifications,
  experience, or years of experience.
- Put mandatory skills in required_skills.
- Put optional, preferred, desirable, or nice-to-have skills in
  preferred_skills.
- required_experience should describe experience areas, not individual tools.
- responsibilities should contain the role's expected duties.
- education_requirements should contain degrees or academic requirements.
- certifications should contain explicitly requested certifications.
- domain_keywords should contain concise industry or technical domains.
- minimum_experience_years must be null unless a numeric minimum is explicit.
- Do not duplicate entries.
- Preserve important technology names such as Python, ROS2, PyTorch,
  FastAPI, Docker, Kubernetes, PostgreSQL, Isaac Sim, and RAG.
- Return empty lists when a category is not present.
""".strip()


class OllamaJobRequirementsProvider:
    """Ollama-backed structured job-requirement extraction provider."""

    def __init__(
        self,
        *,
        base_url: str,
        model: str,
        timeout_seconds: float = 300.0,
        api_key: str | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        cleaned_base_url = base_url.strip().rstrip("/")
        cleaned_model = model.strip()

        if not cleaned_base_url:
            raise ValueError("Ollama base URL must not be empty")

        if not cleaned_model:
            raise ValueError("Ollama model must not be empty")

        if timeout_seconds <= 0:
            raise ValueError("Ollama timeout must be greater than zero")

        self._base_url = cleaned_base_url
        self._model = cleaned_model
        self._timeout_seconds = timeout_seconds
        self._api_key = api_key.strip() if api_key else None
        self._client = client

    @property
    def provider_name(self) -> str:
        return "ollama"

    @property
    def model_name(self) -> str:
        return self._model

    async def extract_requirements(
        self,
        *,
        title: str,
        company: str,
        location: str | None,
        description: str,
    ) -> JobRequirementsData:
        schema = JobRequirementsData.model_json_schema()

        prompt = self._build_prompt(
            title=title,
            company=company,
            location=location,
            description=description,
            schema=schema,
        )

        payload = {
            "model": self._model,
            "messages": [
                {
                    "role": "system",
                    "content": SYSTEM_PROMPT,
                },
                {
                    "role": "user",
                    "content": prompt,
                },
            ],
            "format": schema,
            "stream": False,
            "options": {
                "temperature": 0,
            },
        }

        headers = {
            "Content-Type": "application/json",
        }

        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        try:
            response = await self._post(
                payload=payload,
                headers=headers,
            )
            response.raise_for_status()

        except httpx.TimeoutException as exc:
            raise JobRequirementsProviderError(
                "Ollama timed out while extracting job requirements"
            ) from exc

        except httpx.HTTPStatusError as exc:
            raise JobRequirementsProviderError(
                f"Ollama returned HTTP {exc.response.status_code} "
                "while extracting job requirements"
            ) from exc

        except httpx.RequestError as exc:
            raise JobRequirementsProviderError(
                "Unable to connect to Ollama while extracting "
                "job requirements"
            ) from exc

        try:
            response_data = response.json()
        except json.JSONDecodeError as exc:
            raise JobRequirementsProviderError(
                "Ollama returned an invalid JSON response"
            ) from exc

        error_message = response_data.get("error")

        if error_message:
            raise JobRequirementsProviderError(
                f"Ollama error: {error_message}"
            )

        message = response_data.get("message")

        if not isinstance(message, dict):
            raise JobRequirementsProviderError(
                "Ollama response does not contain a message"
            )

        content = message.get("content")

        if not isinstance(content, str) or not content.strip():
            raise JobRequirementsProviderError(
                "Ollama response does not contain structured content"
            )

        try:
            return JobRequirementsData.model_validate_json(content)
        except ValidationError as exc:
            raise JobRequirementsProviderError(
                "Ollama returned content that does not match "
                "the job-requirements schema"
            ) from exc

    async def _post(
        self,
        *,
        payload: dict[str, object],
        headers: dict[str, str],
    ) -> httpx.Response:
        url = f"{self._base_url}/api/chat"

        if self._client is not None:
            return await self._client.post(
                url,
                json=payload,
                headers=headers,
                timeout=self._timeout_seconds,
            )

        async with httpx.AsyncClient() as client:
            return await client.post(
                url,
                json=payload,
                headers=headers,
                timeout=self._timeout_seconds,
            )

    @staticmethod
    def _build_prompt(
        *,
        title: str,
        company: str,
        location: str | None,
        description: str,
        schema: dict[str, object],
    ) -> str:
        location_text = location or "Not specified"
        schema_text = json.dumps(
            schema,
            sort_keys=True,
            separators=(",", ":"),
        )

        return (
            "Extract structured job requirements from the following job.\n\n"
            f"Title: {title}\n"
            f"Company: {company}\n"
            f"Location: {location_text}\n\n"
            "Job description:\n"
            f"{description}\n\n"
            "Your response must conform to this JSON schema:\n"
            f"{schema_text}"
        )